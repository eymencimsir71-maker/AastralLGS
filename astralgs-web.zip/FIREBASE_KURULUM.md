# AstraLGS üyelik sistemi kurulumu (ücretsiz)

Üyelik için Google'ın Firebase servisini kullanıyoruz. Ücretsiz plan (Spark) bu kullanım için yeterlidir.

## 1. Firebase projesi
1. https://console.firebase.google.com adresine gir, Google hesabınla giriş yap.
2. **Add project** → ad: `astralgs` → Google Analytics'i kapat → Create.

## 2. E-posta ile giriş
1. Sol menü: **Build → Authentication → Get started**.
2. **Sign-in method** sekmesinde **Email/Password** satırını aç, **Enable** yapıp kaydet.
3. **Settings → Authorized domains** bölümünde `kullaniciadin.github.io` adresinin listede olduğunu kontrol et (yoksa **Add domain** ile ekle).

## 3. Veritabanı (ilerleme ve notlar burada saklanır)
1. Sol menü: **Build → Firestore Database → Create database**.
2. Konum seç (Europe-west gibi), **Production mode** ile başlat.
3. **Rules** sekmesine gir, içindeki metni `firestore.rules` dosyasındaki metinle değiştir, **Publish** de.
   Bu kural sadece kendi hesabının verisini okuyup yazabilmeni sağlar.

## 4. Web uygulaması yapılandırması
1. Proje ana sayfasında **Project settings** (dişli simgesi) → **Your apps** → **</>** (Web) simgesine tıkla.
2. Uygulama adı: `astralgs-web` → Register app.
3. Ekranda çıkan `firebaseConfig` bloğundaki değerleri kopyala.
4. `index.html` dosyasını aç ve en üstteki `FB_CONFIG` satırını bu değerlerle değiştir:
   ```
   const FB_CONFIG={apiKey:"...",authDomain:"...",projectId:"...",appId:"..."};
   ```
   Dosyada `BURAYA_` ile başlayan yerler kalmamalı.

## 5. Yayınlama
Dosyaları (index.html, sw.js, manifest.json, icon.svg) GitHub reposuna yükle. Birkaç dakika sonra site üyelik ekranıyla açılır.

## Notlar
- Üyeliksiz kullanım da çalışır. Üye olmak sadece verileri cihazlar arası eşitler.
- Eşitleme "son kaydeden kazanır" mantığıyla çalışır. Aynı anda iki cihazda çalışırsan son kaydedilen veri geçerli olur.
- Şifre ve kişisel bilgiler Firebase tarafında tutulur; sen şifreleri göremezsin.
- Android APK içindeki sürüm (AstraLGS-Java) yerel dosya üzerinden açıldığı için giriş özelliği çalışmayabilir. Üyelik için web sürümünü kullan.
- Ücretsiz kotalar (günlük okuma/yazma sayısı) bu uygulama için bol bol yeterlidir.
